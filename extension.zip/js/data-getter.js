//get formatted date
function formatDate(date) {
    // Ensure date is a Date object
    if (!(date instanceof Date)) {
        throw new Error('Invalid Date object passed to formatDate function');
    }

    // Extract date components
    const month = date.getMonth() + 1; // Month is zero-based, so add 1
    const day = date.getDate();
    const year = date.getFullYear();
    const hours = date.getHours();
    const minutes = date.getMinutes();

    // Pad single-digit numbers with leading zeros if necessary
    const formattedMonth = month < 10 ? `0${month}` : `${month}`;
    const formattedDay = day < 10 ? `0${day}` : `${day}`;
    let formattedHours = hours < 10 ? `0${hours}` : `${hours}`;
    let formattedMinutes = minutes < 10 ? `0${minutes}` : `${minutes}`;

    // Determine if it's AM or PM
    const period = hours >= 12 ? 'pm' : 'am';

    // Adjust hours for PM display (12-hour format)
    if (formattedHours > 12) {
        formattedHours -= 12;
    }

    // Add period (am/pm) to formattedMinutes
    formattedMinutes += ` ${period}`;

    // Now you have your formatted time
    const formattedTime = `${formattedHours}:${formattedMinutes}`;
    // Construct the formatted date string
    const formattedDate = `${formattedMonth}-${formattedDay}-${year} ${formattedTime}`;

    return formattedDate;
}

// Example usage:
const currentDate = new Date();
console.log(formatDate(currentDate)); // Output example: "07-10-2024 14:30"

// Function to draw the pie chart
function drawPieChart(data, container) {
    const total = data.reduce((sum, { value }) => sum + value, 0);
    let startAngle = 0;

    // SVG setup
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "-1 -1 2 2"); // viewBox for full circle

    // Loop through data to create slices
    data.forEach(({ label, value, color }) => {
        const angle = (value / total) * 360;
        const endAngle = startAngle + angle;

        // Calculate path of the slice
        const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
        const d = [
            `M ${Math.sin(startAngle * Math.PI / 180)}, ${-Math.cos(startAngle * Math.PI / 180)}`, // Starting point (top of circle)
            `A 1, 1 0 ${angle > 180 ? 1 : 0}, 1`, // Arc
            `${Math.sin(endAngle * Math.PI / 180)}, ${-Math.cos(endAngle * Math.PI / 180)}`, // End point
            "L 0, 0" // Line back to center
        ].join(" ");

        path.setAttribute("d", d);
        path.setAttribute("fill", color);

        // Add tooltip (optional)
        path.setAttribute("title", `${label}: ${value}`);

        // Append slice to SVG
        svg.appendChild(path);

        // Update start angle for the next slice
        startAngle = endAngle;
    });

    // Append SVG to container
    container.appendChild(svg);
}
async function fetchDataAndDisplay() {
    try {
        document.querySelector('.lobby__side').innerHTML = "<h2>Loading....</h2>"
        const user_tag = document.querySelector('#user_tag')
        const victoryElement = '<div data-icon="" class="my-icon"></div>'
        const defeatElement = '<div data-icon="" class="my-icon"></div>'
        let count = 0
        const response = await fetch(`https://lichess.org/@/${user_tag ? user_tag.textContent : 'Ford_Crown_Vic'}/perf/kingOfTheHill`);
        if (!response.ok) {
            throw new Error('Failed to fetch data');
        }
        const htmlText = await response.text();
        const doc = new DOMParser().parseFromString(htmlText, 'text/html');
        let rank = -1
        if (user_tag) {
            const response2 = await fetch('https://lichess.org/player/top/200/kingOfTheHill')
            const htmlText2 = await response2.text()
            const doc2 = new DOMParser().parseFromString(htmlText2, 'text/html')
            rank = Array.from(doc2.querySelectorAll('tr a')).findIndex(item => item.href.replace('https://lichess.org/@/', '') === user_tag.textContent)
        }
        // Getting victories data
        const victoriesArray = Array.from(doc.querySelectorAll('tr')[6]?.querySelectorAll('td') || []).map(td => td.textContent.trim());

        // Getting defeats data
        const defeatsArray = Array.from(doc.querySelectorAll('tr')[8]?.querySelectorAll('td') || []).map(td => td.textContent.trim());

        // Getting streaks data
        const longestStreak = doc.querySelector('.streak strong')?.textContent || ''
        const longestStreakDate = Array.from(doc.querySelector('.streak')?.querySelectorAll('time') || []).map(item => new Date(item.getAttribute('datetime')))
        const currentStreak = doc.querySelectorAll('.streak')[1].querySelector('strong')?.textContent || null
        const currenttStreakDate = Array.from(doc.querySelectorAll('.streak')[1]?.querySelectorAll('time') || []).map(item => new Date(item.getAttribute('datetime')))
        // Getting highest rated wins data
        const highesRatedWinsArray = Array.from(doc.querySelectorAll('table')[2]?.querySelectorAll('td') || []).map(td => td.textContent.trim());

        // Render to div.lobby__timeline
        const sideElement = `
        <h4>Victories/Defeats</h4>
    <section class="section">
    <div id="chart-container"></div>
    <div id="my-content">
        <div class="myWin">${victoryElement} ${victoriesArray[0]} <span>||</span> ${victoriesArray[1]}</div>
        <div class="myLosse">${defeatElement} ${defeatsArray[0]} <span>||</span> ${defeatsArray[1]}</div>
    </div>
    </section>
    <h4>Streaks</h4>
    <section class="section">
    ${longestStreak.length > 0 ?
                ` <div ><p class="underline-text">Longest</p>: <p class="myWin"><strong>${longestStreak}</strong> Games</p></div>
        <div>from <time>${formatDate(longestStreakDate[0])}</time> to <time>${formatDate(longestStreakDate[1])}</time></div>
        ${currentStreak ? `<div ><p class="underline-text">Current</p>: <p class="myWin"><strong>${currentStreak}</strong> Games</p></div><div>from <time>${formatDate(currenttStreakDate[0])}</time> to <time>${formatDate(currenttStreakDate[1])}</time></div>` : ''}` : ''
            }
    </section>
    <h4>Best Rated</h4>
    <section class="section">
        ${highesRatedWinsArray.map(item => {
                ++count
                if (count % 2 === 0) {
                    return `<time class="info">${item}</time>`
                }
                return `<div class="info">${item}</div>`
            }).join('')}
    </section>
    ${rank !== -1 ?
                `<section class="section">
        <div>Rank: <p class="myWin">${rank + 1}</p></div>
        </section>`: ''

            }
        `;
        document.querySelector('div.lobby__side').innerHTML = sideElement;
        const chartContainer = document.getElementById('chart-container')
        drawPieChart([{ label: 'win', value: Number(victoriesArray[1].replace('%', '')), color: 'aqua' }, { label: 'loose', value: Number(defeatsArray[1].replace('%', '')), color: 'red' }], chartContainer)
    } catch (error) {
        console.error('Error fetching or parsing data:', error);
        // Handle error, maybe show a message on the page
        document.querySelector('.lobby__side').innerHTML = "<h2>Something Went Wrong</h2>"
    }
}

// Call the function to fetch and display data
fetchDataAndDisplay();
